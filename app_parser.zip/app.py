from flask import Flask, request, jsonify, render_template, send_from_directory
from werkzeug.utils import secure_filename
from docx import Document
import pdfplumber
import os
import re
import json
from datetime import datetime

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['HISTORY_FOLDER'] = 'history'
app.config['JSON_AS_ASCII'] = False
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['HISTORY_FOLDER'], exist_ok=True)


def clean_text(text):
    if not text:
        return ""
    text = text.replace('\xa0', ' ')
    text = text.replace('\r', '\n')
    text = ''.join(ch for ch in text if ch == '\n' or ch == '\t' or ord(ch) >= 32)
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def extract_text_from_pdf(file_path):
    try:
        with pdfplumber.open(file_path) as pdf:
            return '\n'.join(page.extract_text() or '' for page in pdf.pages)
    except Exception as e:
        print(f"PDF error: {e}")
        return ""


def extract_text_from_docx(file_path):
    try:
        doc = Document(file_path)
        text_parts = []

        # Извлечение из параграфов
        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)

        # Извлечение из таблиц
        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    if cell.text.strip():
                        row_text.append(cell.text.strip())
                if row_text:
                    text_parts.append(' | '.join(row_text))

        return '\n'.join(text_parts)
    except Exception as e:
        print(f"DOCX error: {e}")
        return ""


def extract_text_from_doc(file_path):
    try:
        import win32com.client
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        doc = word.Documents.Open(os.path.abspath(file_path))
        text = doc.Content.Text
        doc.Close()
        word.Quit()
        return text
    except Exception as e:
        print(f"DOC error: {e}")
        return ""


def extract_text(file_path):
    if '.' not in file_path:
        return ""

    ext = file_path.rsplit('.', 1)[1].lower()
    extractors = {
        'pdf': extract_text_from_pdf,
        'docx': extract_text_from_docx,
        'doc': extract_text_from_doc,
        'txt': lambda p: open(p, 'r', encoding='utf-8').read()
    }

    extractor = extractors.get(ext)
    if extractor:
        try:
            return clean_text(extractor(file_path))
        except Exception as e:
            print(f"Extraction error: {e}")
            return ""
    return ""


def extract_all_entities(text):
    """Извлечение сущностей с отслеживанием ненайденных полей"""

    entities = {}
    missing_fields = []

    def add_field(category, field_name, value, required=False):
        """Добавление поля с проверкой на пустоту"""
        if category not in entities:
            entities[category] = {}

        if value is not None and value != "" and value != []:
            entities[category][field_name] = value
        else:
            if required or field_name in ['total_amount', 'supplier', 'customer']:
                missing_fields.append(f"{category}.{field_name}")

    # ===== ИНФОРМАЦИЯ О ДОГОВОРЕ =====

    # Номер договора
    contract_num = re.search(r'ДОГОВОР\s+(?:ПОСТАВКИ|КУПЛИ-ПРОДАЖИ|ПОДРЯДА)?\s*(?:№|No\.?|Номер)\s*([\d\-\/]+)', text,
                             re.IGNORECASE)
    add_field('contract_info', 'number', contract_num.group(1).strip() if contract_num else None)

    # Дата договора
    date_match = re.search(
        r'(?:«|")?(\d{1,2})\s+(январ[яь]|феврал[яь]|март[а]?|апрел[яь]|ма[яй]|июн[яь]|июл[яь]|август[а]?|сентябр[яь]|октябр[яь]|ноябр[яь]|декабр[яь])\s+(\d{4})\s*(?:года|г\.?)?',
        text, re.IGNORECASE)
    add_field('contract_info', 'date',
              f"{date_match.group(1)} {date_match.group(2)} {date_match.group(3)} года" if date_match else None)

    # Город
    city_match = re.search(r'г\.\s*([А-Яа-яЁё\s\-]+?)(?:\n|,|\s+\d|$)', text)
    add_field('contract_info', 'city', city_match.group(1).strip() if city_match else None)

    # Тип договора
    if 'поставки' in text.lower():
        add_field('contract_info', 'type', 'поставки')
    elif 'купли-продажи' in text.lower():
        add_field('contract_info', 'type', 'купли-продажи')
    elif 'подряда' in text.lower():
        add_field('contract_info', 'type', 'подряда')
    else:
        missing_fields.append('contract_info.type')

    # ===== СТОРОНЫ ДОГОВОРА =====

    party_pattern = r'(ООО|ЗАО|ОАО|АО|ПАО|ИП)\s*[«"]([^«"]+?)[»"]\s*,\s*в\s*лице\s*([^,]+),\s*действующ[а-я]+.*?именуем[а-я]+.*?«(Поставщик|Покупатель|Заказчик|Исполнитель)»'
    all_parties = re.findall(party_pattern, text, re.IGNORECASE)

    supplier_found = False
    customer_found = False

    for party in all_parties:
        legal_form, name, representative, role = party

        party_data = {
            "legal_form": legal_form.strip(),
            "name": name.strip(),
            "representative": representative.strip(),
            "role": role
        }

        if role in ['Поставщик', 'Исполнитель', 'Продавец'] and not supplier_found:
            add_field('parties', 'supplier', party_data, required=True)
            supplier_found = True
        elif role in ['Покупатель', 'Заказчик'] and not customer_found:
            add_field('parties', 'customer', party_data, required=True)
            customer_found = True

    # Если не нашли — ищем по порядку
    if not supplier_found or not customer_found:
        simple_pattern = r'(ООО|ЗАО|ОАО|АО|ПАО|ИП)\s*[«"]([^«"]+?)[»"]'
        companies = re.findall(simple_pattern, text)

        if len(companies) >= 2:
            if not supplier_found:
                add_field('parties', 'supplier', {
                    "legal_form": companies[0][0].strip(),
                    "name": companies[0][1].strip(),
                    "role": "Поставщик"
                }, required=True)
            if not customer_found:
                add_field('parties', 'customer', {
                    "legal_form": companies[1][0].strip(),
                    "name": companies[1][1].strip(),
                    "role": "Покупатель"
                }, required=True)

    # ===== РЕКВИЗИТЫ =====

    inn_all = re.findall(r'ИНН\s*(\d{10,12})', text)
    add_field('parties', 'inn', list(set(inn_all)) if inn_all else None)

    kpp_all = re.findall(r'КПП\s*(\d{9})', text)
    add_field('parties', 'kpp', list(set(kpp_all)) if kpp_all else None)

    ogrn_all = re.findall(r'ОГРН\s*(\d{13,15})', text)
    add_field('parties', 'ogrn', list(set(ogrn_all)) if ogrn_all else None)

    okpo_all = re.findall(r'ОКПО\s*(\d{8,10})', text)
    add_field('parties', 'okpo', list(set(okpo_all)) if okpo_all else None)

    # Банковские реквизиты
    bank_match = re.search(r'(?:р/с|расч[её]тный\s*сч[её]т)\s*[№]?\s*(\d{20})', text)
    add_field('financial', 'bank_account', bank_match.group(1) if bank_match else None)

    corr_account = re.search(r'(?:к/с|корр?\.?\s*сч[её]т)\s*[№]?\s*(\d{20})', text)
    add_field('financial', 'corr_account', corr_account.group(1) if corr_account else None)

    bik_match = re.search(r'БИК\s*(\d{9})', text)
    add_field('financial', 'bik', bik_match.group(1) if bik_match else None)

    # Банк
    bank_patterns = [
        r'(?:Банк|в\s+банке)\s*[:\-]?\s*(.+?)(?:\n|$)',
        r'Банк\s+(.+?)\s+(?:р/с|расч|БИК|ИНН)',
    ]
    bank_found = False
    for pattern in bank_patterns:
        bank_match = re.search(pattern, text, re.IGNORECASE)
        if bank_match:
            bank_name = re.sub(r'[«»"\']', '', bank_match.group(1)).strip()
            if bank_name and len(bank_name) > 2:
                add_field('financial', 'bank', bank_name)
                bank_found = True
                break

    # ===== ФИНАНСОВАЯ ИНФОРМАЦИЯ =====

    amount_patterns = [
        r'(?:Общая\s+)?(?:стоимость|сумма|цена)\s+(?:товара|договора|по\s+договору)?\s*(?:составляет|:|–|—)\s*([\d\s]+[\.,]?\d*)\s*(?:\([^)]+\))?\s*(?:руб|₽)?',
        r'на\s+сумму\s+([\d\s]+[\.,]?\d*)\s*(?:\([^)]+\))?\s*(?:руб|₽)?',
        r'([\d]{1,3}(?:\s*\d{3})*[\.,]?\d*)\s*(?:\([^)]+\))?\s*(?:руб|₽)',
    ]

    amount_found = False
    for pattern in amount_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            amount_str = match.group(1).replace(' ', '').replace(',', '.')
            try:
                amount = float(amount_str)
                add_field('financial', 'total_amount', {
                    "value": amount,
                    "currency": "RUB",
                    "text": match.group(0).strip()
                }, required=True)
                amount_found = True
                break
            except:
                continue

    if not amount_found:
        missing_fields.append('financial.total_amount')

    # НДС
    if re.search(r'(?:без|не\s*облагается|освобождён)\s*(?:от\s*)?НДС', text, re.IGNORECASE):
        add_field('financial', 'vat', 'Без НДС')
    else:
        vat_match = re.search(r'(?:в\s*том\s*числе\s*)?НДС\s*(?:–|—|:|\s)?\s*(\d+[\.,]?\d*)\s*%', text, re.IGNORECASE)
        if vat_match:
            add_field('financial', 'vat', f"{vat_match.group(1)}%")

    # ===== КОНТАКТЫ =====

    phones = re.findall(r'(?:\+7|8)\s*\(?\d{3}\)?\s*\d{3}[\s\-]?\d{2}[\s\-]?\d{2}', text)
    add_field('contacts', 'phones', list(set(phones)) if phones else None)

    emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
    add_field('contacts', 'emails', list(set(emails)) if emails else None)

    # ===== АДРЕСА =====

    legal_addr = re.findall(r'Юридический\s*адрес[:\s]*(.+?)(?:\n|$)', text, re.IGNORECASE)
    add_field('addresses', 'legal', [addr.strip() for addr in legal_addr] if legal_addr else None)

    postal_addr = re.findall(r'Почтовый\s*адрес[:\s]*(.+?)(?:\n|$)', text, re.IGNORECASE)
    add_field('addresses', 'postal', [addr.strip() for addr in postal_addr] if postal_addr else None)

    actual_addr = re.findall(r'Фактический\s*адрес[:\s]*(.+?)(?:\n|$)', text, re.IGNORECASE)
    add_field('addresses', 'actual', [addr.strip() for addr in actual_addr] if actual_addr else None)

    postcodes = re.findall(r'\b(\d{6})\b', text)
    add_field('addresses', 'postcodes', list(set(postcodes)) if postcodes else None)

    # ===== ПРЕДМЕТ ДОГОВОРА =====
    subject_section = re.search(
        r'(?:1\.?\s*)?(?:Предмет договора|ПРЕДМЕТ ДОГОВОРА).*?(?=(?:2\.|II\.|\n(?:[2-9]|[А-ЯЁ])))',
        text, re.IGNORECASE | re.DOTALL
    )
    add_field('contract_info', 'subject', subject_section.group(0).strip()[:500] if subject_section else None)

    # ===== ПОРЯДОК ОПЛАТЫ =====
    payment_section = re.search(
        r'(?:Порядок\s+оплаты|Условия\s+оплаты|3\.\s*(?:ПОРЯДОК|Порядок)).*?(?=(?:4\.|IV\.|\n(?:[4-9]|[А-ЯЁ])))',
        text, re.IGNORECASE | re.DOTALL
    )
    add_field('financial', 'payment_terms', payment_section.group(0).strip()[:1000] if payment_section else None)

    # ===== СРОКИ =====

    validity = re.search(
        r'(?:договор\s+(?:вступает\s+в\s+силу|действует)|срок\s+действия).*?(?:до|по)\s*(\d{1,2}[\.\/]\d{1,2}[\.\/]\d{2,4})',
        text, re.IGNORECASE
    )
    add_field('dates', 'valid_until', validity.group(1) if validity else None)

    delivery_date = re.search(
        r'(?:срок|период)\s+(?:поставки|отгрузки|передачи)[:\s]*(.+?)(?:\n|\.|$)',
        text, re.IGNORECASE
    )
    add_field('dates', 'delivery_period', delivery_date.group(1).strip() if delivery_date else None)

    # ===== ОТВЕТСТВЕННОСТЬ =====

    penalties = re.findall(
        r'(?:неустойк[аи]|пен[яи]|штраф)\s*.*?(\d+[\.,]?\d*)\s*%',
        text, re.IGNORECASE
    )
    add_field('terms', 'penalties_percent', penalties if penalties else None)

    # ===== ПОДПИСАНТЫ =====

    signers = re.findall(
        r'(?:Поставщик|Покупатель|Заказчик|Исполнитель)\s*[:]?\s*(?:_______________|_______)?\s*/?\s*([А-ЯЁ][а-яё]+\s+[А-ЯЁ]\.[А-ЯЁ]\.)',
        text, re.IGNORECASE
    )
    add_field('signatures', 'signers', [s.strip() for s in signers] if signers else None)

    return entities, missing_fields


def parse_contract(text, filename):
    """Парсинг договора с полным извлечением данных"""
    if not text:
        return {"error": "Empty text"}

    # Извлекаем сущности и ненайденные поля
    detailed_info, missing_fields = extract_all_entities(text)

    # Превью текста
    preview = text[:300] + "..." if len(text) > 300 else text

    # Статистика
    stats = {
        "total_fields_searched": 25,
        "found_fields": 25 - len(missing_fields),
        "missing_fields": missing_fields,
        "completeness": round((25 - len(missing_fields)) / 25 * 100, 1)
    }

    result = {
        "status": "success",
        "filename": filename,
        "processed_at": datetime.now().isoformat(),
        "preview": preview,
        "detailed_info": detailed_info,
        "stats": stats
    }

    return result


def save_to_history(result_data):
    """Сохранение в историю поиска"""
    history_file = os.path.join(app.config['HISTORY_FOLDER'], 'search_history.json')

    history = []
    if os.path.exists(history_file):
        with open(history_file, 'r', encoding='utf-8') as f:
            try:
                history = json.load(f)
            except:
                history = []

    # Добавляем запись в историю
    history_entry = {
        "timestamp": result_data["processed_at"],
        "filename": result_data["filename"],
        "contract_number": result_data["detailed_info"].get("contract_info", {}).get("number", "Не указан"),
        "contract_date": result_data["detailed_info"].get("contract_info", {}).get("date", "Не указана"),
        "parties": {
            "supplier": result_data["detailed_info"].get("parties", {}).get("supplier", {}).get("name", "Не найден"),
            "customer": result_data["detailed_info"].get("parties", {}).get("customer", {}).get("name", "Не найден")
        },
        "amount": result_data["detailed_info"].get("financial", {}).get("total_amount", {}).get("value", "Не указана"),
        "completeness": result_data["stats"]["completeness"],
        "missing_fields": result_data["stats"]["missing_fields"]
    }

    history.insert(0, history_entry)  # В начало списка

    # Храним последние 100 записей
    history = history[:100]

    with open(history_file, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

    return history


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'Файл не найден'}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({'error': 'Имя файла пустое'}), 400

    if not allowed_file(file.filename):
        return jsonify({'error': 'Неподдерживаемый формат. Разрешены: pdf, docx, doc, txt'}), 400

    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_filename = f"{timestamp}_{filename}"
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)

    try:
        file.save(file_path)
        text = extract_text(file_path)

        if not text:
            return jsonify({'error': 'Не удалось извлечь текст'}), 400

        # Парсим с передачей оригинального имени файла
        parsed_data = parse_contract(text, filename)

        # Сохраняем результат в JSON
        result_filename = f"{os.path.splitext(unique_filename)[0]}_result.json"
        result_path = os.path.join(app.config['UPLOAD_FOLDER'], result_filename)

        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump(parsed_data, f, ensure_ascii=False, indent=2)

        # Сохраняем в историю
        history = save_to_history(parsed_data)

        return jsonify({
            "filename": unique_filename,
            "status": "success",
            "data": parsed_data,
            "history": history[:10],  # Последние 10 записей
            "download_url": f"/download/{result_filename}"
        })

    except Exception as e:
        return jsonify({'error': f'Ошибка обработки: {str(e)}'}), 500


@app.route('/history')
def get_history():
    """Получение истории поиска"""
    history_file = os.path.join(app.config['HISTORY_FOLDER'], 'search_history.json')

    if os.path.exists(history_file):
        with open(history_file, 'r', encoding='utf-8') as f:
            try:
                history = json.load(f)
                return jsonify({"status": "success", "history": history})
            except:
                return jsonify({"status": "success", "history": []})

    return jsonify({"status": "success", "history": []})


@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'pdf', 'docx', 'doc', 'txt'}


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)